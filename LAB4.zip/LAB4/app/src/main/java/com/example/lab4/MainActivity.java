package com.example.lab4;


import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    int status=0;
    Handler handler = new Handler();
    ProgressBar p;
    TextView textView;
    private int cat_launcher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        status = 0;
        p = findViewById(R.id.progressBar);
        textView = findViewById(R.id.text_view);
        Button bd = findViewById(R.id.button_dialog);
        ImageView image = new ImageView(this);
        image.setImageResource(cat_launcher);
        image.setMaxWidth(20);
        image.setMaxHeight(20);
        bd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(MainActivity.this)
                        .setIcon(cat_launcher)
                        .setTitle("Your Alert")
                        .setMessage("Your Message")
                        .setMessage("Your Message")
                        .setCancelable(false)
                        .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //Whatever...
                            }
                        })
                        .setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //whatever...
                            }
                        }).show();
            }
        });
        new Thread(new Runnable() {
            @Override
            public void run() {
                while(status<100){
                    handler.post(new Runnable() {
                        public void run() {
                            p.setProgress(status);
                            textView.setText(status+"/"+p.getMax());
                        }
                    });
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    if(status==99){
                        status=1;
                    }
                    status++;
                }
            }
        }).start();

    }
}